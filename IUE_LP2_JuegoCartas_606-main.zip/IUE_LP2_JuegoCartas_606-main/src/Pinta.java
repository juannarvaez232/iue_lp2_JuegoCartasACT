public enum Pinta {
    TREBOL,
    PICA,
    CORAZON,
    DIAMANTE
}

 