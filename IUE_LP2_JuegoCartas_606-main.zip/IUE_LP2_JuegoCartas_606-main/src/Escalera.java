import java.util.ArrayList;
import java.util.List;

public class Escalera {

    public static List<String> detectarEscaleras(Jugador jugador) {
        List<String> escaleras = new ArrayList<>();
        Carta[] cartas = jugador.getCartas();

        
        ordenarCartasPorNombreYPinta(cartas);


        for (Pinta pinta : Pinta.values()) {
            List<NombreCarta> secuencia = new ArrayList<>();
            for (Carta carta : cartas) {
                if (carta.getPinta() == pinta) {
                    if (secuencia.isEmpty() || esSiguienteCarta(secuencia.get(secuencia.size() - 1), carta.getNombre())) {
                        secuencia.add(carta.getNombre());
                    } else {
                        if (secuencia.size() >= 2) {
                            escaleras.add("Escalera de " + pinta + ": " + secuencia);
                        }
                        secuencia.clear();
                        secuencia.add(carta.getNombre());
                    }
                }
            }
      
            if (secuencia.size() >= 2) {
                escaleras.add("Escalera de " + pinta + ": " + secuencia);
            }
        }

        return escaleras;
    }

    private static void ordenarCartasPorNombreYPinta(Carta[] cartas) {
        for (int i = 0; i < cartas.length - 1; i++) {
            for (int j = i + 1; j < cartas.length; j++) {
                if (cartas[i].getPinta().ordinal() > cartas[j].getPinta().ordinal() ||
                    (cartas[i].getPinta() == cartas[j].getPinta() && 
                     cartas[i].getNombre().ordinal() > cartas[j].getNombre().ordinal())) {
                    Carta temp = cartas[i];
                    cartas[i] = cartas[j];
                    cartas[j] = temp;
                }
            }
        }
    }

    private static boolean esSiguienteCarta(NombreCarta anterior, NombreCarta siguiente) {
        return siguiente.ordinal() == anterior.ordinal() + 1;
    }

    public static int calcularPuntaje(Jugador jugador) {
        int puntaje = 0;
        Carta[] cartas = jugador.getCartas();
        List<String> escaleras = detectarEscaleras(jugador);

        
        for (Carta carta : cartas) {
            boolean enEscalera = false;
            for (String escalera : escaleras) {
                if (escalera.contains(carta.getNombre().toString())) {
                    enEscalera = true;
                    break;
                }
            }
            if (!enEscalera) {
                puntaje += obtenerValorCarta(carta);
            }
        }

        return puntaje;
    }

    private static int obtenerValorCarta(Carta carta) {
        switch (carta.getNombre()) {
            case AS:
            case JACK:
            case QUEEN:
            case KING:
                return 10;
            default:
                return carta.getNombre().ordinal() + 1;
        }
    }
}